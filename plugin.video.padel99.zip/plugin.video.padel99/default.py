# -*- coding: utf-8 -*-
#------------------------------------------------------------
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon


addonID = 'plugin.video.padel99'

local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID1 = "WorldPadelTourAJPP"
YOUTUBE_CHANNEL_ID2 = "UCJwA1JoiwXGmfUzW3djvjaQ"
YOUTUBE_CHANNEL_ID3 = "padeladdict"
YOUTUBE_CHANNEL_ID4 = "UCyJ89bNIXthD-Uy_0DUCcrg"
YOUTUBE_CHANNEL_ID5 = "UCXq1MW9mooMiSzC2gCCYcXQ"
YOUTUBE_CHANNEL_ID6 = "UCmdpAsfM6ELdHFX_abwhmfw"
YOUTUBE_CHANNEL_ID7 = "UCHgX157GlMQMy6j4c5YWwXQ"
YOUTUBE_CHANNEL_ID8 = "UClx9gLfTq0gX8oC0j_nkAGw"
YOUTUBE_CHANNEL_ID9 = "UCK4TIJK5bXgSUAd7prJWLhg"




# Entry point
def run():
    plugintools.log("padel99.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("padel99.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="World Padel Tour",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID1+"/",
        thumbnail="https://2.bp.blogspot.com/-5ldPYErIRoc/X3DVeM8EMhI/AAAAAAABnQo/8sBsQlKnbHoqbK0HLPI47qLi-CQm_3LiQCLcBGAsYHQ/s1600/worldpadel.png",
		fanart="https://www.worldpadeltour.com/media-content/2019/01/wpt-presentacion-logo-cian-1900x1086px-1900x1086.jpg",
        folder=True )

		
    plugintools.add_item( 
        #action="", 
        title="Zona de Padel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail="https://2.bp.blogspot.com/-V6bBZv4UbP0/X3HBGfUsQdI/AAAAAAABnRY/BLHMF423Dz0ekg0H26zykIEOLMRp2fZPgCLcBGAsYHQ/s1600/zonadepadel.jpg",
    	fanart="https://www.elconfidencialdigital.com/asset/zoomcrop,1366,800,center,center//media/elconfidencialdigital/images/2019/07/16/2019071613560882142.jpg",
		folder=True )

    plugintools.add_item( 
        #action="", 
        title="Padel Addict",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID3+"/",
        thumbnail="https://3.bp.blogspot.com/-17osB5oVwsk/X3HDgl4XGcI/AAAAAAABnRk/oBy14_w361I3fVP8-N4yMbycnUw5fJuhwCLcBGAsYHQ/s1600/padel%2Badict.png",
    	fanart="https://padeladdict.com/wp-content/uploads/2015/05/tecnicas-alucinantes-padel.jpg",
		folder=True )

    plugintools.add_item( 
        #action="", 
        title="Mejora tu Padel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID4+"/",
        thumbnail="https://4.bp.blogspot.com/-w12Oyh1JOVw/WYwhl4JUJmI/AAAAAAAAcMw/KFKAG76sCXQdO8Sid_FvMQssY-hNOIlBQCLcBGAs/s1600/m.png",
    	fanart="https://4.bp.blogspot.com/-vcYXvax1cc4/WYwfjNUxZCI/AAAAAAAAcMk/Z5-QzP6-UjAI4Cc7nqRBChytLrwZyrnxgCLcBGAs/s1600/maxresdefault.jpg",
		folder=True )

    plugintools.add_item( 
        #action="", 
        title="Padel Television TV",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID5+"/",
        thumbnail="https://2.bp.blogspot.com/-5iTKEw3R3Uw/X3G-yjaNK7I/AAAAAAABnRM/IErtCA5gQ90ckMK09NJ5HRWdLvg-7P3oACLcBGAsYHQ/s1600/padeltv.jpg",
    	fanart="https://static.wixstatic.com/media/9a3df7_7b6f7baffe684e16bc0dd934fcdb2b5c~mv2.jpg/v1/fill/w_1895,h_1048,al_c,q_90,usm_0.66_1.00_0.01/9a3df7_7b6f7baffe684e16bc0dd934fcdb2b5c~mv2.webp",
		folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Rodrigo Ovide Pádel Coach",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID6+"/",
        thumbnail="https://1.bp.blogspot.com/-uf0sUujcZFQ/X3G58cCnYRI/AAAAAAABnRA/6_BdEO616xsPJLBret_lD_DO2Fxdi_ivgCLcBGAsYHQ/s1600/rodrigo-ovide-videos.jpg",
    	fanart="https://rodriovide.com/wp-content/uploads/2018/07/2017-09-12-12-22-17-21.jpg",
		folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="J3Padel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID7+"/",
        thumbnail="https://1.bp.blogspot.com/-q2KE9sVxjUw/X29VfdRKiqI/AAAAAAABnQY/3sXaZGuAl2YuFw_iFabwVc7JBePiPI2FQCLcBGAsYHQ/s1600/j3padel.jpg",
    	fanart="https://infodelmedia.com/img/proyectos/j3padel/j3padel2.jpg",
		folder=True )

    plugintools.add_item( 
        #action="", 
        title="Aprende Pádel con Hugo Cases",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID8+"/",
        thumbnail="https://2.bp.blogspot.com/-nW49WkBqoH0/X3HG0vHpWRI/AAAAAAABnRw/pdpFvtc195ofVZ6sRvpv5TxfSDkEApnQgCLcBGAsYHQ/s1600/jugo.jpg",
    	fanart="https://padelworldpress.es/wp-content/uploads/2014/11/hugo.jpg",
		folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="el4Set",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID9+"/",
        thumbnail="https://1.bp.blogspot.com/-f_JJNPYJ8q0/X3HJnmfgZTI/AAAAAAABnR8/VWaWMQNdVk4RZTR9GFGgawx_YsQRo1jfACLcBGAsYHQ/s1600/4set.jpg",
    	fanart="https://i.pinimg.com/originals/38/36/06/3836065e60690f84d0d70cdaeb5222df.jpg",
		folder=True )







        
run()